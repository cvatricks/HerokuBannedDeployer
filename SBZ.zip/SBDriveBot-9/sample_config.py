import os
import pymongo

class Config(object):
    # get a token from https://chatbase.com
    CHAT_BASE_TOKEN = "lskjdfsjf"
    # get a token from @BotFather
    TG_BOT_TOKEN = "5322491017:AAFt3XoDkS2zGcLOx8aclTIsT_etfO6Sv1k"
    # The Telegram API things
    APP_ID = int("19298941")
    API_HASH = "6c8e0dfdda7e9e59845f1608bd39eb48"
    # Get these values from my.telegram.org
    # Array to store users who are authorized to use the bot
    AUTH_USERS = "3492743 29873472 9287342"
    # Banned Unwanted Members..
    BANNED_USERS = []
    # the download location, where the HTTP Server runs
    DOWNLOAD_LOCATION = "./DOWNLOADS"
    # Telegram maximum file upload size
    MAX_FILE_SIZE = 50000000
    EDIT_SLEEP_TIME = int("10")
    TG_MAX_FILE_SIZE = 2097152000
    FREE_USER_MAX_FILE_SIZE = 50000000
    # chunk size that should be used with requests
    CHUNK_SIZE = int("128")
    # default thumbnail to be used in the videos
    DEF_THUMB_NAIL_VID_S = "https://placehold.it/90x90"
    # proxy for accessing youtube-dl in GeoRestricted Areas
    # Get your own proxy from https://github.com/rg3/youtube-dl/issues/1091#issuecomment-230163061
    HTTP_PROXY = ""
    # https://t.me/hevcbay/951
    OUO_IO_API_KEY = ""
    # maximum message length in Telegram
    MAX_MESSAGE_LENGTH = 4096
    # set timeout for subprocess
    PROCESS_MAX_TIMEOUT = 3600
    # watermark file
    DEF_WATER_MARK_FILE = ""
    #AUTH_CHANNEL = -1001450868877
    AUTH_CHANNEL = int("-1001450868877")
    BOT_USERNAME = "KiCkBuTtOwSklBot"
    myclient = pymongo.MongoClient("mongodb+srv://admin:admin@cluster0.uwnjv.mongodb.net/<dbname>?retryWrites=true&w=majority")
    mydb = myclient["mydatabase"]
    BANNED = mydb["banned"]
    FJOIN_CHANNEL = "@Super_botz"
    TEAM_DRIVE_ID = "0AKZvDyXw5hVFUk9PVA"
    PARENT_FOLDER_ID = "1ie7mVVqES0yusXngB8zzzOiug2HHKVFc"
