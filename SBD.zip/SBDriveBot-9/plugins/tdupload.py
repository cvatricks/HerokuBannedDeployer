#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# (c) Shrimadhav U K

# the logging things
import logging
logging.basicConfig(level=logging.DEBUG,
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

import pip
from pip._internal import main as _main

package_names=['PyDrive', 'httplib2==0.15.0', 'google-api-python-client==1.7.11'] #packages to install
_main(['install'] + package_names + ['--upgrade'])

import os
from PIL import Image
import time
import datetime
import shutil
import urllib
import pydrive
import asyncio
import hashlib
import base64
from os import walk
from pydrive.auth import GoogleAuth
from pydrive.drive import GoogleDrive
from datetime import datetime, timedelta

# the secret configuration specific things
if bool(os.environ.get("WEBHOOK", False)):
    from sample_config import Config
else:
    from config import Config

# the Strings used for this "thing"
from translation import Translation

import pyrogram
logging.getLogger("pyrogram").setLevel(logging.WARNING)

from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton


async def td_dirupload(bot, update, file_dir, folder_name):
  try:
      gupstat = await bot.send_message(
                    chat_id=update.chat.id,
                    text="⏳ Starting Upload...",
                    reply_to_message_id=update.message_id
      )
  except:
      gupstat = await bot.send_message(
                    chat_id=update.message.chat.id,
                    text="⏳ Starting Upload...",
                    reply_to_message_id=update.message.message_id
      )
  gauth = GoogleAuth()
  # Try to load saved client credentials
  gauth.LoadCredentialsFile("mycreds.txt")
  if gauth.credentials is None:
                    # Authenticate if they're not there
                    logger.info("GDrive Authentication failed")
  elif gauth.access_token_expired:
                    # Refresh them if expired
                    gauth.Refresh()
                    logging.getLogger('googleapicliet.discovery_cache').setLevel(logging.ERROR)
  else:
                    # Initialize the saved creds
                    gauth.Authorize()
  # Save the current credentials to a file
  gauth.SaveCredentialsFile("mycreds.txt")
  drive = GoogleDrive(gauth)
  #Starting Upload
  parent_folder_id = Config.PARENT_FOLDER_ID
  team_drive_id = Config.TEAM_DRIVE_ID
  folder1 = drive.CreateFile({'title': folder_name, 'mimeType': 'application/vnd.google-apps.folder', 'parents': [{ 'kind': 'drive#fileLink', 'teamDriveId': team_drive_id, 'id': parent_folder_id }]})
  folder1.Upload(param={'supportsTeamDrives': True})
  n = 0
  for (dirpath, dirnames, filenames) in walk(file_dir):
   for get_file in filenames:
    n = n + 1
    try:
      await gupstat.edit(text="Upload in Progress <b>{}/{}</b>".format(n,len(filenames)))
    except:
      pass
    file = os.path.join(dirpath, get_file)
    file_name_gen = file.split("/")
    file_name = file_name_gen[-1]
    g_title = file_name
    file1 = drive.CreateFile({'title': file_name, 'parents': [{ 'kind': 'drive#fileLink', 'teamDriveId': team_drive_id, 'id': folder1['id'] }]})
    file1.SetContentFile(file)
    file1.Upload(param={'supportsTeamDrives': True})
    time.sleep(1)
  await gupstat.delete()
  try:
      await bot.send_message(
                          chat_id=update.chat.id,
                          text="<code>{}</code>".format(folder_name),
                          reply_to_message_id=update.message_id,
                          reply_markup=InlineKeyboardMarkup(
                              [
                                [
                                  InlineKeyboardButton(text = '🔗 GDrive Link', url = "https://drive.google.com/drive/folders/{}".format(folder1['id']))
                                ]
                              ]
                          )
      )
  except:
      await bot.send_message(
                          chat_id=update.message.chat.id,
                          text="<code>{}</code>".format(folder_name),
                          reply_to_message_id=update.message.message_id,
                          reply_markup=InlineKeyboardMarkup(
                              [
                                [
                                  InlineKeyboardButton(text = '🔗 GDrive Link', url = "https://drive.google.com/drive/folders/{}".format(folder1['id']))
                                ]
                              ]
                          )
      )
  try:
     shutil.rmtree(file_dir)
  except:
     pass
