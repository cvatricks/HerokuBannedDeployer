#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# (c) Shrimadhav U K

# the logging things
import logging
logging.basicConfig(level=logging.DEBUG,
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

import pip
from pip._internal import main as _main

package_names=['lbry-libtorrent', 'bencodepy'] #packages to install
_main(['install'] + package_names + ['--upgrade'])

import numpy
import os
from PIL import Image
import time
import datetime
import shutil
import urllib
import random
import asyncio
import bencodepy
import hashlib
import base64
import libtorrent as lt
from datetime import datetime, timedelta
from os import walk

# the secret configuration specific things
if bool(os.environ.get("WEBHOOK", False)):
    from sample_config import Config
else:
    from config import Config

# the Strings used for this "thing"
from translation import Translation

import pyrogram
logging.getLogger("pyrogram").setLevel(logging.WARNING)

#from helper_funcs.chat_base import TRChatBase
from helper_funcs.display_progress import progress_for_pyrogram
from hachoir.metadata import extractMetadata
from hachoir.parser import createParser
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from plugins.dl_button import ddl_call_back
from plugins.tdupload import td_dirupload
from helper_funcs.help_Nekmo_ffmpeg import take_screen_shot


@pyrogram.Client.on_message(pyrogram.filters.command(["gleech@" + Config.BOT_USERNAME]) & pyrogram.filters.chat(chats=Config.AUTH_CHANNEL))
async def gleech(bot, update):
  for banned in Config.BANNED.find():
                banuser = banned.get("user_id")
                if int(update.from_user.id) == int(banuser):
                  await update.reply_text("😐 You are B A N N E D")
                  return
  try:
      await bot.get_chat_member(
                chat_id=Config.FJOIN_CHANNEL,
                user_id=update.from_user.id
      )
  except pyrogram.errors.exceptions.bad_request_400.UserNotParticipant:
      await bot.send_message(
                    chat_id=update.chat.id,
                    text="Hey, you were not yet joined in our channel!",
                    parse_mode="html",
                    reply_to_message_id=update.message_id,
                    reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton(text = '✅ Updates Channel', url = "https://t.me/Super_botz")]])
      )
      return
  #TRChatBase(update.from_user.id, update.text, "converttovideo")
  if update.reply_to_message is not None:
      try:
       if update.reply_to_message.text.lower().startswith("magnet:"):
         nnn = update.reply_to_message.text.split("btih:")
         nnnn = nnn[1].split("&")
         ses = lt.session()
         ses.listen_on(6881, 6891)
         params = {
           'save_path': Config.DOWNLOAD_LOCATION + "/" + str(update.from_user.id) + "/" + nnnn[0],
           'storage_mode': lt.storage_mode_t(2)
         }
         link = update.reply_to_message.text
       elif update.reply_to_message.text.lower().startswith("http"):
         await update.reply_text("😏 try with ytdl cmd")
         return
      except:
       if update.reply_to_message.document.file_name.lower().endswith(".torrent"):
           down_file = Config.DOWNLOAD_LOCATION + "/" + str(update.from_user.id) + ".torrent"
           ttt = await bot.download_media(
                   message=update.reply_to_message,
                   file_name=down_file
                 )
           logger.info(ttt)
           try:
             metadata = bencodepy.decode_from_file(down_file)
             subj = metadata[b'info']
             hashcontents = bencodepy.encode(subj)
             digest = hashlib.sha1(hashcontents).digest()
             b32hash = base64.b32encode(digest).decode()
             try:
               an_name = metadata[b'announce'].decode()
             except:
               an_name = ""
             try:
               ln_name = str(metadata[b'info'][b'length'])
             except:
               ln_name = ""
             ses = lt.session()
             ses.listen_on(6881, 6891)
             link = "magnet:?xt=urn:btih:{}&dn={}&tr={}&xl={}".format(b32hash, metadata[b'info'][b'name'].decode(), an_name, ln_name)
             nnn = link.split("btih:")
             nnnn = nnn[1].split("&")
             params = {
               'save_path': Config.DOWNLOAD_LOCATION + "/" + str(update.from_user.id) + "/" + nnnn[0],
               'storage_mode': lt.storage_mode_t(2)
             }
             try:
                shutil.rmtree(down_file)
             except:
                pass
           except Exception as e:
             await update.reply_text(
                  e
             )
             return
      handle = lt.add_magnet_uri(ses, link, params)
      ses.start_dht()
      a = await bot.send_message(
            chat_id=update.chat.id,
            text="⏳ Analysing",
            reply_to_message_id=update.message_id,
            parse_mode="html",
            disable_web_page_preview=True
          )
      meta_time = datetime.now() + timedelta(minutes = 5)
      scount = 300
      while (not handle.has_metadata()):
        await a.edit(text="🔍 Finding metadata..\n\n🕒 Max. wait time {}s left".format(scount))
        scount = scount - 10
        await asyncio.sleep(Config.EDIT_SLEEP_TIME)
        #meta_time = meta_time + 1
        if datetime.strptime(str(meta_time), '%Y-%m-%d %H:%M:%S.%f') < datetime.now():
           await a.edit(text="<b>#Cancelled</b>\n\nDue to slow torrent or may be dead.")
           return
      await a.edit(
        text="⏳ Starting Download..."
      )
      while (handle.status().state != lt.torrent_status.seeding):
        s = handle.status()
        state_str = ['queued', 'checking', 'downloading metadata', \
            'downloading', 'finished', 'seeding', 'allocating']
        try:
          await a.edit(
            text="Download in progress <b>{:.2f}%</b> \n\n<code>{}</code>\n\n⬇️: <code>{:.2f}</code> KB/s \n⬆️: <code>{:.2f}</code> KB/s \nPeers: {}".format(s.progress * 100, handle.get_torrent_info().name(), s.download_rate / 1000, s.upload_rate / 1000, s.num_peers)
          )
        except:
          pass
        await asyncio.sleep(Config.EDIT_SLEEP_TIME)
      try:
          file_dir_gen = os.listdir(Config.DOWNLOAD_LOCATION + "/" + str(update.from_user.id) + "/" + nnnn[0] + "/" + handle.get_torrent_info().name() + "/")
          file_dir = Config.DOWNLOAD_LOCATION + "/" + str(update.from_user.id) + "/" + nnnn[0] + "/" + handle.get_torrent_info().name() + "/"
      except:
          file_dir_gen = os.listdir(Config.DOWNLOAD_LOCATION + "/" + str(update.from_user.id) + "/" + nnnn[0] + "/")
          file_dir = Config.DOWNLOAD_LOCATION + "/" + str(update.from_user.id) + "/" + nnnn[0] + "/"
      folder_name = handle.get_torrent_info().name()
      await a.delete()
      await td_dirupload(bot, update, file_dir, folder_name)
  else:
        await update.delete()

@pyrogram.Client.on_message(pyrogram.filters.command(["leech@" + Config.BOT_USERNAME]) & pyrogram.filters.chat(chats=Config.AUTH_CHANNEL))
async def leech(bot, update):
  for banned in Config.BANNED.find():
                banuser = banned.get("user_id")
                if int(update.from_user.id) == int(banuser):
                  await update.reply_text("😐 You are B A N N E D")
                  return
  try:
      await bot.get_chat_member(
                chat_id=Config.FJOIN_CHANNEL,
                user_id=update.from_user.id
      )
  except pyrogram.errors.exceptions.bad_request_400.UserNotParticipant:
      await bot.send_message(
                    chat_id=update.chat.id,
                    text="Hey, you were not yet joined in our channel!",
                    parse_mode="html",
                    reply_to_message_id=update.message_id,
                    reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton(text = '✅ Updates Channel', url = "https://t.me/Super_botz")]])
      )
      return
  #TRChatBase(update.from_user.id, update.text, "converttovideo")
  if update.reply_to_message is not None:
      try:
       if update.reply_to_message.text.lower().startswith("magnet:"):
         nnn = update.reply_to_message.text.split("btih:")
         nnnn = nnn[1].split("&")
         ses = lt.session()
         ses.listen_on(6881, 6891)
         params = {
           'save_path': Config.DOWNLOAD_LOCATION + "/" + str(update.from_user.id) + "/" + nnnn[0],
           'storage_mode': lt.storage_mode_t(2)
         }
         link = update.reply_to_message.text
       elif update.reply_to_message.text.lower().startswith("http"):
         await update.reply_text("😏 try with ytdl cmd")
         return
      except:
       if update.reply_to_message.document.file_name.lower().endswith(".torrent"):
           down_file = Config.DOWNLOAD_LOCATION + "/" + str(update.from_user.id) + ".torrent"
           ttt = await bot.download_media(
                   message=update.reply_to_message,
                   file_name=down_file
                 )
           logger.info(ttt)
           try:
             metadata = bencodepy.decode_from_file(down_file)
             subj = metadata[b'info']
             hashcontents = bencodepy.encode(subj)
             digest = hashlib.sha1(hashcontents).digest()
             b32hash = base64.b32encode(digest).decode()
             try:
               an_name = metadata[b'announce'].decode()
             except:
               an_name = ""
             try:
               ln_name = str(metadata[b'info'][b'length'])
             except:
               ln_name = ""
             ses = lt.session()
             ses.listen_on(6881, 6891)
             link = "magnet:?xt=urn:btih:{}&dn={}&tr={}&xl={}".format(b32hash, metadata[b'info'][b'name'].decode(), an_name, ln_name)
             nnn = link.split("btih:")
             nnnn = nnn[1].split("&")
             params = {
               'save_path': Config.DOWNLOAD_LOCATION + "/" + str(update.from_user.id) + "/" + nnnn[0],
               'storage_mode': lt.storage_mode_t(2)
             }
             try:
                shutil.rmtree(down_file)
             except:
                pass
           except Exception as e:
             await update.reply_text(
                  e
             )
             return
      handle = lt.add_magnet_uri(ses, link, params)
      ses.start_dht()
      a = await bot.send_message(
            chat_id=update.chat.id,
            text="⏳ Analysing",
            reply_to_message_id=update.message_id,
            parse_mode="html",
            disable_web_page_preview=True
          )
      meta_time = datetime.now() + timedelta(minutes = 5)
      scount = 300
      while (not handle.has_metadata()):
        await a.edit(text="🔍 Finding metadata..\n\n🕒 Max. wait time {}s left".format(scount))
        scount = scount - 10
        await asyncio.sleep(Config.EDIT_SLEEP_TIME)
        #meta_time = meta_time + 1
        if datetime.strptime(str(meta_time), '%Y-%m-%d %H:%M:%S.%f') < datetime.now():
           await a.edit(text="<b>#Cancelled</b>\n\nDue to slow torrent or may be dead.")
           return
      await a.edit(
        text="Starting Download..."
      )
      while (handle.status().state != lt.torrent_status.seeding):
        s = handle.status()
        state_str = ['queued', 'checking', 'downloading metadata', \
            'downloading', 'finished', 'seeding', 'allocating']
        try:
          await a.edit(
            text="Download in progress <b>{:.2f}%</b> \n\n<code>{}</code>\n\n⬇️: <code>{:.2f}</code> KB/s \n⬆️: <code>{:.2f}</code> KB/s \nPeers: {}".format(s.progress * 100, handle.get_torrent_info().name(), s.download_rate / 1000, s.upload_rate / 1000, s.num_peers)
          )
        except:
          pass
        await asyncio.sleep(Config.EDIT_SLEEP_TIME)
      try:
          file_dir_gen = os.listdir(Config.DOWNLOAD_LOCATION + "/" + str(update.from_user.id) + "/" + nnnn[0] + "/" + handle.get_torrent_info().name() + "/")
          file_dir = Config.DOWNLOAD_LOCATION + "/" + str(update.from_user.id) + "/" + nnnn[0] + "/" + handle.get_torrent_info().name() + "/"
      except:
          file_dir_gen = os.listdir(Config.DOWNLOAD_LOCATION + "/" + str(update.from_user.id) + "/" + nnnn[0] + "/")
          file_dir = Config.DOWNLOAD_LOCATION + "/" + str(update.from_user.id) + "/" + nnnn[0] + "/"
      thumb_image_path = Config.DOWNLOAD_LOCATION + "/" + str(update.from_user.id) + ".jpg"
      for (dirpath, dirnames, filenames) in walk(file_dir):
        for get_file in filenames:
            file = os.path.join(dirpath, get_file)
            u_time = time.time()
            file_size = os.stat(file).st_size
            if file_size > Config.TG_MAX_FILE_SIZE:
                await bot.send_message(
                    chat_id=update.chat.id,
                    text="😐 <b>Detected file size {:.2f} GB.</b>\n\n<code>{}</code> is <b>out of TG API Limit</b>".format(file_size / 1073741824, file.split("/")[-1]),
                    reply_to_message_id=update.message_id
                )
                continue
            duration = None
            try:
              metadata = extractMetadata(createParser(file))
              if metadata is not None:
                    if metadata.has("duration"):
                        duration = metadata.get('duration').seconds
            except Exception as e:
              await update.reply_text(str(e))
            if duration is not None:
              if not os.path.exists(thumb_image_path):
                thumb_image_path = await take_screen_shot(
                    file,
                    os.path.dirname(file),
                    random.randint(
                        0,
                        duration - 1
                    )
                )
                #thumb_image = urllib.request.urlretrieve("https://1.bp.blogspot.com/-LVZiuoJc2ik/X-zavfEil3I/AAAAAAAANMM/XjkOSz11g-o98DUQH8n-706JSYQ4jkUQwCLcBGAsYHQ/s320/index.jpg", Config.DOWNLOAD_LOCATION + "/" + str(update.from_user.id) + ".jpg")
                logger.info(thumb_image_path)
            # get the correct width, height, and duration for videos greater than 10MB
            if os.path.exists(thumb_image_path):
                width = 0
                height = 0
                image = Image.open(thumb_image_path) 
                image_size = image.size 
                width = image_size[0] 
                height = image_size[1]
                #metadata = extractMetadata(createParser(thumb_image_path))
                #if metadata.has("width"):
                #    width = metadata.get("width")
                #if metadata.has("height"):
                #    height = metadata.get("height")
                #if tg_send_type == "vm":
                #    height = width             
            #else:
            #thumb_image_path = None
            if duration is not None:
                send_type = "video"
                # resize image
                # ref: https://t.me/PyrogramChat/44663
                # https://stackoverflow.com/a/21669827/4723940
                Image.open(thumb_image_path).convert(
                    "RGB").save(thumb_image_path)
                img = Image.open(thumb_image_path)
                # https://stackoverflow.com/a/37631799/4723940
                # img.thumbnail((90, 90))
                if send_type == "file":
                    img.resize((320, height))
                else:
                    img.resize((90, height))
                img.save(thumb_image_path, "JPEG")
                # https://pillow.readthedocs.io/en/3.1.x/reference/Image.html#create-thumbnails
            elif duration is None:
                send_type = "file"
            file_name_gen = file.split('/')
            file_name = file_name_gen[-1]
            if send_type == "file":
                await bot.send_document(
                    chat_id=update.chat.id,
                    document=file,
                    thumb=None,
                    caption=file_name,
                    parse_mode="HTML",
                    # reply_markup=reply_markup,
                    reply_to_message_id=update.reply_to_message.message_id,
                    progress=progress_for_pyrogram,
                    progress_args=(
                        "Upload in progress\n\n{}".format(file_name),
                        a,
                        u_time
                    )
                )
            elif send_type == "video":
                await bot.send_video(
                    chat_id=update.chat.id,
                    video=file,
                    caption=file_name,
                    parse_mode="HTML",
                    duration=duration,
                    width=width,
                    height=height,
                    supports_streaming=True,
                    # reply_markup=reply_markup,
                    thumb=thumb_image_path,
                    reply_to_message_id=update.reply_to_message.message_id,
                    progress=progress_for_pyrogram,
                    progress_args=(
                        "Upload in progress\n\n{}".format(file_name),
                        a,
                        u_time
                    )
                )
            else:
                logger.info("Did this happen? :\\")

      await a.edit("#Uploaded\n\n<code>{}</code>".format(handle.get_torrent_info().name()))
      try:
            shutil.rmtree(file_dir)
      except:
            pass
  else:
        await update.delete()

@pyrogram.Client.on_message(pyrogram.filters.command(["tleech@" + Config.BOT_USERNAME]) & pyrogram.filters.chat(chats=Config.AUTH_CHANNEL))
async def tleech(bot, update):
    for banned in Config.BANNED.find():
                banuser = banned.get("user_id")
                if int(update.from_user.id) == int(banuser):
                  await update.reply_text("😐 You are B A N N E D")
                  return
    try:
      await bot.get_chat_member(
                chat_id=Config.FJOIN_CHANNEL,
                user_id=update.from_user.id
      )
    except pyrogram.errors.exceptions.bad_request_400.UserNotParticipant:
      await bot.send_message(
                    chat_id=update.chat.id,
                    text="Hey, you were not yet joined in our channel!",
                    parse_mode="html",
                    reply_to_message_id=update.message_id,
                    reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton(text = '✅ Updates Channel', url = "https://t.me/Super_botz")]])
      )
      return
    #TRChatBase(update.from_user.id, update.text, "converttovideo")
    if update.reply_to_message is not None:
        download_location = Config.DOWNLOAD_LOCATION + "/" + str(update.from_user.id) + "/" + str(update.reply_to_message.caption) + "/"
        a = await bot.send_message(
            chat_id=update.chat.id,
            text="Download in progress",
            reply_to_message_id=update.message_id
        )
        c_time = time.time()
        start_download = datetime.now()
        try:
         the_real_download_location = await bot.download_media(
            message=update.reply_to_message,
            file_name=download_location,
            progress=progress_for_pyrogram,
            progress_args=(
                "Download in progress...",
                a,
                c_time
            )
         )
         await a.delete()
        except ValueError:
          await a.edit(
               text="Reply to TG File/Video."
          )
          return
        file_dir = download_location
        folder_name = str(update.reply_to_message.caption)
        await td_dirupload(bot, update, file_dir, folder_name)
    else:
        await update.delete()

#@pyrogram.Client.on_message(pyrogram.Filters.command(["generatecustomthumbnail"]))
async def generate_custom_thumbnail(bot, update):
    if update.from_user.id in Config.BANNED_USERS:
        await bot.delete_messages(
            chat_id=update.chat.id,
            message_ids=update.message_id,
            revoke=True
        )
        return
    #TRChatBase(update.from_user.id, update.text, "generatecustomthumbnail")
    if update.reply_to_message is not None:
        reply_message = update.reply_to_message
        if reply_message.media_group_id is not None:
            download_location = Config.DOWNLOAD_LOCATION + "/" + str(update.from_user.id) + "/" + str(reply_message.media_group_id) + "/"
            save_final_image = download_location + str(round(time.time())) + ".jpg"
            list_im = os.listdir(download_location)
            if len(list_im) == 2:
                imgs = [ Image.open(download_location + i) for i in list_im ]
                inm_aesph = sorted([(numpy.sum(i.size), i.size) for i in imgs])
                min_shape = inm_aesph[1][1]
                imgs_comb = numpy.hstack(numpy.asarray(i.resize(min_shape)) for i in imgs)
                imgs_comb = Image.fromarray(imgs_comb)
                # combine: https://stackoverflow.com/a/30228789/4723940
                imgs_comb.save(save_final_image)
                # send
                await bot.send_photo(
                    chat_id=update.chat.id,
                    photo=save_final_image,
                    caption=Translation.CUSTOM_CAPTION_UL_FILE,
                    reply_to_message_id=update.message_id
                )
            else:
                await bot.send_message(
                    chat_id=update.chat.id,
                    text=Translation.ERR_ONLY_TWO_MEDIA_IN_ALBUM,
                    reply_to_message_id=update.message_id
                )
            try:
                [os.remove(download_location + i) for i in list_im ]
                os.remove(download_location)
            except:
                pass
        else:
            await bot.send_message(
                chat_id=update.chat.id,
                text=Translation.REPLY_TO_MEDIA_ALBUM_TO_GEN_THUMB,
                reply_to_message_id=update.message_id
            )
    else:
        await bot.send_message(
            chat_id=update.chat.id,
            text=Translation.REPLY_TO_MEDIA_ALBUM_TO_GEN_THUMB,
            reply_to_message_id=update.message_id
        )


@pyrogram.Client.on_message(pyrogram.filters.photo & pyrogram.filters.chat(chats=Config.AUTH_CHANNEL))
async def save_photo(bot, update):
    for banned in Config.BANNED.find():
                banuser = banned.get("user_id")
                if int(update.from_user.id) == int(banuser):
                  await update.reply_text("😐 You are B A N N E D")
                  return
    try:
      await bot.get_chat_member(
                chat_id=Config.FJOIN_CHANNEL,
                user_id=update.from_user.id
      )
    except pyrogram.errors.exceptions.bad_request_400.UserNotParticipant:
      await bot.send_message(
                    chat_id=update.chat.id,
                    text="Hey, you were not yet joined in our channel!",
                    parse_mode="html",
                    reply_to_message_id=update.message_id,
                    reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton(text = '✅ Updates Channel', url = "https://t.me/Super_botz")]])
      )
      return
    #TRChatBase(update.from_user.id, update.text, "save_photo")
    if update.media_group_id is not None:
        # album is sent
        download_location = Config.DOWNLOAD_LOCATION + "/" + str(update.from_user.id) + "/" + str(update.media_group_id) + "/"
        # create download directory, if not exist
        if not os.path.isdir(download_location):
            os.makedirs(download_location)
        await bot.download_media(
            message=update,
            file_name=download_location
        )
    else:
        # received single photo
        download_location = Config.DOWNLOAD_LOCATION + "/" + str(update.from_user.id) + ".jpg"
        await bot.download_media(
            message=update,
            file_name=download_location
        )
        await bot.send_message(
            chat_id=update.chat.id,
            text=Translation.SAVED_CUSTOM_THUMB_NAIL,
            reply_to_message_id=update.message_id
        )


@pyrogram.Client.on_message(pyrogram.filters.command(["clearthumbnail@" + Config.BOT_USERNAME]) & pyrogram.filters.chat(chats=Config.AUTH_CHANNEL))
async def clear_thumbnail(bot, update):
    for banned in Config.BANNED.find():
                banuser = banned.get("user_id")
                if int(update.from_user.id) == int(banuser):
                  await update.reply_text("😐 You are B A N N E D")
                  return
    try:
      await bot.get_chat_member(
                chat_id=Config.FJOIN_CHANNEL,
                user_id=update.from_user.id
      )
    except pyrogram.errors.exceptions.bad_request_400.UserNotParticipant:
      await bot.send_message(
                    chat_id=update.chat.id,
                    text="Hey, you were not yet joined in our channel!",
                    parse_mode="html",
                    reply_to_message_id=update.message_id,
                    reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton(text = '✅ Updates Channel', url = "https://t.me/Super_botz")]])
      )
      return
    #TRChatBase(update.from_user.id, update.text, "deletethumbnail")
    download_location = Config.DOWNLOAD_LOCATION + "/" + str(update.from_user.id)
    try:
        os.remove(download_location + ".jpg")
        # os.remove(download_location + ".json")
    except:
        pass
    await bot.send_message(
        chat_id=update.chat.id,
        text=Translation.DEL_ETED_CUSTOM_THUMB_NAIL,
        reply_to_message_id=update.message_id
    )
