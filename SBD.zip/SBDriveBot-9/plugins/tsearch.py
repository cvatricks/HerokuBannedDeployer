#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# (c) CvaTricks

# the logging things
import logging
logging.basicConfig(level=logging.DEBUG,
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

import os
import time
import datetime
import shutil
import requests
import random
import json
import asyncio


# the secret configuration specific things
if bool(os.environ.get("WEBHOOK", False)):
    from sample_config import Config
else:
    from config import Config

# the Strings used for this "thing"
from translation import Translation

import pyrogram
logging.getLogger("pyrogram").setLevel(logging.WARNING)
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton

async def tsearch(bot, update, query, api):
  res = "https://api.abirhasan.wtf/" + api + "?query=" + query
  results = requests.get(res).json()
  if update.message.reply_to_message.from_user.id != update.from_user.id:
        await bot.answer_callback_query(
            callback_query_id=update.id,
            text="who are you? 🤪🤔🤔🤔",
            show_alert=True,
            cache_time=0
        )
        return
  with open("{}.json".format(update.from_user.id), "w", encoding="utf8") as outfile:
              json.dump(results, outfile, ensure_ascii=False)
  try:
    sz =  results["results"][0]["Size"]
  except:
    sz = "Unknown"
  try:
     result_text = "1. {}\n\n{}\n\nSeeders:{}\n\n<code>{}</code>".format(results["results"][0]["Name"], sz, results["results"][0]["Seeders"],results["results"][0]["Magnet"])
     await bot.edit_message_text(
                  text=result_text,
                  chat_id=update.message.chat.id,
                  message_id=update.message.message_id,
                  disable_web_page_preview=True,
                  reply_markup=InlineKeyboardMarkup(
                    [
                     [
                      InlineKeyboardButton("➡️",callback_data="next_btn")
                     ]
                    ]
                  )
     )
  except:
     await bot.answer_callback_query(
            callback_query_id=update.id,
            text="🚫 No Results were found !",
            show_alert=True,
            cache_time=0
     )
     return
#Torrent Search with /search command
@pyrogram.Client.on_message(pyrogram.filters.command(["search@" + Config.BOT_USERNAME]) & pyrogram.filters.chat(chats=Config.AUTH_CHANNEL))
async def tsearc(bot, update):
  for banned in Config.BANNED.find():
                banuser = banned.get("user_id")
                if int(update.from_user.id) == int(banuser):
                  await update.reply_text("😐 You are B A N N E D")
                  return
  try:
      await bot.get_chat_member(
                chat_id=Config.FJOIN_CHANNEL,
                user_id=update.from_user.id
      )
  except pyrogram.errors.exceptions.bad_request_400.UserNotParticipant:
      await bot.send_message(
                    chat_id=update.chat.id,
                    text="Hey, you were not yet joined in our channel!",
                    parse_mode="html",
                    reply_to_message_id=update.message_id,
                    reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton(text = '✅ Updates Channel', url = "https://t.me/Super_botz")]])
      )
      return
  if update.reply_to_message is not None:
      try:
       if update.reply_to_message.text is not None:
         query = update.reply_to_message.text 
         inline_keyboard = [
           [
             InlineKeyboardButton("✨ 1337x",callback_data="tsearch_1337x")
           ],
           [
             InlineKeyboardButton("✨ ThePirateBay",callback_data="tsearch_piratebay")
           ],
           [
             InlineKeyboardButton("✨ YTS",callback_data="tsearch_yts")
           ]
         ]
         reply_markup = InlineKeyboardMarkup(inline_keyboard)
         await bot.send_message(
            chat_id=update.chat.id,
            text="Query : {}\n\n Select Torrent Client 👇".format(query),
            reply_to_message_id=update.message_id,
            reply_markup=reply_markup
         )
       else:
         await update.reply_text("😏 reply to search query")
         return
      except:
         await update.delete()
  else:
     await update.delete()
