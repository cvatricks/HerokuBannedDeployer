## [Link To File v5.25](https://telegram.dog/llnk2filebot) - ORG
---



**My Features**:

👉 All Supported Video Formats of https://rg3.github.io/youtube-dl/supportedsites.html

👉 Upload as file from any HTTP link

### Installation
[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy)
#### The Easiest Way

**USE OUR BOT 😍**

#### The Hard Way

```sh
virtualenv -p python3 VENV
. ./VENV/bin/activate
pip install -r requirements.txt
cp sample_config.py config.py
--- EDIT config.py values appropriately ---
python bot.py
```


## Credits, and Thanks to

* [Dan Tès](https://telegram.dog/haskell) for his [Pyrogram Library](https://github.com/pyrogram/pyrogram)
* [Yoily](https://telegram.dog/YoilyL) for his [UploaditBot](https://telegram.dog/UploaditBot)


#### LICENSE
- GPLv3
